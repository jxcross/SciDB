/*============================================================================
  CMake - Cross Platform Makefile Generator
  Copyright 2000-2012 Kitware, Inc., Insight Software Consortium

  Distributed under the OSI-approved BSD License (the "License");
  see accompanying file Copyright.txt for details.

  This software is distributed WITHOUT ANY WARRANTY; without even the
  implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the License for more information.
============================================================================*/

#include "cmExportSet.h"
#include "cmTargetExport.h"

cmExportSet::~cmExportSet()
{
  for(unsigned int i = 0; i < this->TargetExports.size(); ++ i)
    {
    delete this->TargetExports[i];
    }
}

void cmExportSet::AddTargetExport(cmTargetExport* te)
{
  this->TargetExports.push_back(te);
}

void cmExportSet::AddInstallation(cmInstallExportGenerator const* installation)
{
  this->Installations.push_back(installation);
}
